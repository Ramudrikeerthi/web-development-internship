document.getElementById("colorBtn").onclick = function () {
  document.body.style.background =
    "#" + Math.floor(Math.random() * 16777215).toString(16);
};

window.onload = function () {
  let hour = new Date().getHours();
  let message = "";

  if (hour < 12) message = "Good Morning 🌅";
  else if (hour < 18) message = "Good Afternoon ☀️";
  else message = "Good Evening 🌙";

  alert(message);
};

function submitForm() {
  let name = document.getElementById("name").value;
  alert("Hello " + name + "!");
}

function addNumbers() {
  let n1 = Number(document.getElementById("num1").value);
  let n2 = Number(document.getElementById("num2").value);
  document.getElementById("result").innerText = "Result: " + (n1 + n2);
}
